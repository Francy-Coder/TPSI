class Cuoco {
    public void prepara(Piatto piatto) {
        System.out.println("Il cuoco sta preparando il piatto");
        piatto.prepara();
    }
}