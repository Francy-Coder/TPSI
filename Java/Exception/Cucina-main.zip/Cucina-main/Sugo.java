class Sugo {
    private String tipo;

    public Sugo(String tipo) {
        this.tipo = tipo;
    }

    public String getTipo() {
        return tipo;
    }
}